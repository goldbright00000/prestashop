<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blocksharefb}prestashop>blocksharefb_d5d8d3eab66d27ce437e210d0ce31fce'] = 'Button "Auf Facebook teilen"';
$_MODULE['<{blocksharefb}prestashop>blocksharefb_1c32abb67032ad28e8613bb67f6e9867'] = 'Erlaubt Ihren Kunden, Artikel oder Inhalte des Shops auf Facebook zu teilen.';
$_MODULE['<{blocksharefb}prestashop>blocksharefb_353005a70db1e1dac3aadedec7596bd7'] = 'Auf Facebook teilen';


return $_MODULE;
