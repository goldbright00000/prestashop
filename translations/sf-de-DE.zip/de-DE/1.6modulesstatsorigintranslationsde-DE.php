<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{statsorigin}prestashop>statsorigin_f0b1507c6bdcdefb60a0e6f9b89d4ae8'] = 'Herkunft der Besucher';
$_MODULE['<{statsorigin}prestashop>statsorigin_a69c2a3091fe48c7f4f391595aa3ac19'] = 'Fügt der Statistik-Übersicht eine graphische Auswertung der Herkunfts-Webseiten Ihrer Besucher hinzu';
$_MODULE['<{statsorigin}prestashop>statsorigin_14542f5997c4a02d4276da364657f501'] = 'Direkter Link';
$_MODULE['<{statsorigin}prestashop>statsorigin_3edf8ca26a1ec14dd6e91dd277ae1de6'] = 'Herkunft';
$_MODULE['<{statsorigin}prestashop>statsorigin_4b69c1f7f555aa19fd90ee01e4aa63cd'] = 'Prozentsatz der 10 beliebtesten Referrer-Webseiten, über die Besucher zu Ihrem Shop gekommen sind.';
$_MODULE['<{statsorigin}prestashop>statsorigin_6602bbeb2956c035fb4cb5e844a4861b'] = 'Erklärung';
$_MODULE['<{statsorigin}prestashop>statsorigin_cec998cc46cd200fa97490137de2cc7f'] = 'Was ist eine Referrer-Webseite?';
$_MODULE['<{statsorigin}prestashop>statsorigin_54f00c2c9a36e2b300b5bacc1bb7912c'] = 'Beim Besuch einer Webseite ist der Referrer die URL der vorherigen Webseite, von der ein Link erfolgte.';
$_MODULE['<{statsorigin}prestashop>statsorigin_7231fe46fc79eb2b3a269f790b79e01f'] = 'Ein Referrer informiert Sie darüber, welche Suchbegriffe Besucher bei Suchmaschinen eingegeben haben, wenn sie zu ihrem Shop geleitet wurden. So können Sie Ihre Internet-Werbung optimieren.';
$_MODULE['<{statsorigin}prestashop>statsorigin_af19c8da1c414055c960a73d86471119'] = 'Referrer können sein:';
$_MODULE['<{statsorigin}prestashop>statsorigin_c227be237c874ba6b2f8771d7b66b90e'] = 'Jemand, der einen Link zu Ihrem Shop auf seiner Webseite hat';
$_MODULE['<{statsorigin}prestashop>statsorigin_ea87a2280d5cdb638a2727147a3dd85c'] = 'Ein Partner, mit dem Sie Links getauscht haben, um die Verkäufe zu erhöhen oder Neukunden anzuziehen';
$_MODULE['<{statsorigin}prestashop>statsorigin_998e4c5c80f27dec552e99dfed34889a'] = 'CSV-Export';
$_MODULE['<{statsorigin}prestashop>statsorigin_96b0141273eabab320119c467cdcaf17'] = 'Gesamt';
$_MODULE['<{statsorigin}prestashop>statsorigin_0bebf95ee829c33f34fde535ed4ed100'] = 'Nur direkte Links';
$_MODULE['<{statsorigin}prestashop>statsorigin_450a7e38e636dd49f5dfb356f96d3996'] = '10 wichtigste Webseiten';
$_MODULE['<{statsorigin}prestashop>statsorigin_52ef9633d88a7480b3a938ff9eaa2a25'] = 'Andere';


return $_MODULE;
