<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{gsitemap}prestashop>gsitemap_3aaaafde6f9b2701f9e6eb9292e95521'] = 'Google Sitemap';
$_MODULE['<{gsitemap}prestashop>gsitemap_935a6bc13704a117d22333c3155b5dae'] = 'Generieren Sie Ihre Google Sitemap-Datei';
$_MODULE['<{gsitemap}prestashop>gsitemap_b52bf50c73995780892b9945ddc98708'] = 'Beim Versuch der Überprüfung Ihrer Dateirechte ist ein Fehler aufgetretem. Bitte passen Sie Rechte an, damit PrestaShop eine Datei im Hauptverzeichnis anlegen kann.';
$_MODULE['<{gsitemap}prestashop>configuration_67ddb0d12fa1963b202d4ac310547709'] = 'Ihre Sitemaps wurden  erstellt. Bitte vergessen Sie nicht, Ihre URL';
$_MODULE['<{gsitemap}prestashop>configuration_9d934413d2737c2a15f58de573657ce3'] = 'in Ihrem Google Webmaster-Account einzutragen.';
$_MODULE['<{gsitemap}prestashop>configuration_1c95b77d135b55c84429588c11697ea4'] = 'Ihre Sitemaps';
$_MODULE['<{gsitemap}prestashop>configuration_aa17b80751f4ae53ab8e3ed2fe99e94d'] = 'Sitemaps bereits erstellt.';
$_MODULE['<{gsitemap}prestashop>configuration_a0bfb8e59e6c13fc8d990781f77694fe'] = 'Weiter';
$_MODULE['<{gsitemap}prestashop>configuration_9ab08b9ceeef857df07ad10e1de9301e'] = 'Bitte tragen Sie die folgende Sitemap-URL in Ihren Google Webmaster-Account ein:';
$_MODULE['<{gsitemap}prestashop>configuration_aef717e48ecd01989c92849d44bff9b6'] = 'URL der Master-Sitemap, die wiederum auf folgende Unter-Sitemaps verweist:';
$_MODULE['<{gsitemap}prestashop>configuration_0dbf904a2b27f036cf06741aad221ecc'] = 'Letztes Update am:';
$_MODULE['<{gsitemap}prestashop>configuration_6d37779958434303f8397436a1484ed8'] = 'Zur optimalen Nutzung des Moduls sollten Sie über Folgendes verfügen';
$_MODULE['<{gsitemap}prestashop>configuration_6a3282611e5ffb8539ce434133073f15'] = 'mindestens ein memory_limi von 128MB.';
$_MODULE['<{gsitemap}prestashop>configuration_f891951357d4892887f0e416c54f972d'] = 'mindestens eine max_execution_time von 30 Sek.';
$_MODULE['<{gsitemap}prestashop>configuration_8156303464de0fba7cb8306cc768e998'] = 'Sie können diese Begrenzungen in der php.ini, ggf. auch in der .htaccess Ihre Shops ändern. Bitte sprechen Sie mit  Ihren Provider.';
$_MODULE['<{gsitemap}prestashop>configuration_0b9b4b91e0a8f59e264202a23d9c57a6'] = 'Sitemap einrichten';
$_MODULE['<{gsitemap}prestashop>configuration_fe242b3dd3f455778072dc7042637a5e'] = 'Je nach Server-Konfiguration und Anzahl der im Katalog aktivierten Artikel werden mehrere Sitemaps generiert.';
$_MODULE['<{gsitemap}prestashop>configuration_7f751d19f85d49a411d5691f5bb0b5f2'] = 'Wie häufig ändern Sie Ihr Angebot?';
$_MODULE['<{gsitemap}prestashop>configuration_f9f90eeaf400d228facde6bc48da5cfb'] = 'immer';
$_MODULE['<{gsitemap}prestashop>configuration_745fd0ea7f576f350a0eed4b8c48a8e2'] = 'stündlich';
$_MODULE['<{gsitemap}prestashop>configuration_bea79186fd7af2da67e59b4b15df5a26'] = 'täglich';
$_MODULE['<{gsitemap}prestashop>configuration_4a11fc05ed694c195f0703605b64da90'] = 'wöchentlich';
$_MODULE['<{gsitemap}prestashop>configuration_708638881f3bac9d9c8c742c79502811'] = 'monatlich';
$_MODULE['<{gsitemap}prestashop>configuration_1bf712896e6077fa0b708e911d8ee0b3'] = 'jährlich';
$_MODULE['<{gsitemap}prestashop>configuration_c7561db7a418dd39b2201dfe110ab4a4'] = 'nie';
$_MODULE['<{gsitemap}prestashop>configuration_e51d91c7bfa9fc658b11afca4d84653c'] = 'Hier klicken, wenn sie überprüfen wollen, ob die Bild-Dateien auf dsem Server sind';
$_MODULE['<{gsitemap}prestashop>configuration_05ff8159ccaef6f0f8391c61a6d0e631'] = 'Alle aktivieren';
$_MODULE['<{gsitemap}prestashop>configuration_0dfcf5f2f5b9ab7c909f9bdca2b53b56'] = 'Markieren Sie die Seiten, welche nicht in Ihrer Sitemap angezeigt werden sollen :';
$_MODULE['<{gsitemap}prestashop>configuration_2ec111ec9826a83509c02bf5e6b797f1'] = 'Sitemap erstellen';
$_MODULE['<{gsitemap}prestashop>configuration_ca99f8a0d484faef3a057fe7a5da3141'] = 'Das kann ein paar Miunten dauern ...';
$_MODULE['<{gsitemap}prestashop>configuration_162b34489ed8df561be1720f04fe6d42'] = 'Sitmaps können auf zweierlei Weise erstellen werden:';
$_MODULE['<{gsitemap}prestashop>configuration_6caa369fd774beef106abbc5cc1e3368'] = 'Manuell:';
$_MODULE['<{gsitemap}prestashop>configuration_4ed0b6a0097c3d38c43d756fe2653962'] = 'übr das obige Formular (so häufig wie erforderlich)';
$_MODULE['<{gsitemap}prestashop>configuration_3d263eb0233f14872193733387840c80'] = '- oder -';
$_MODULE['<{gsitemap}prestashop>configuration_957d27165d1dc5947fb00e57967ffcce'] = 'Automatisch:';
$_MODULE['<{gsitemap}prestashop>configuration_024d2d2f6d7fd575701fd1b30cc5c0c2'] = 'Bitte Sie Ihren Provider, einen "Cronjob" zu erstellen, um die folgenden URL zur festgelegten Zeit zu laden:';
$_MODULE['<{gsitemap}prestashop>configuration_8076be06e575e50c7f9585271c8842ad'] = 'Erstellt automatisch Ihre XML-Sitemaps.';
$_MODULE['<{gsitemap}prestashop>configuration_98a9d595be84a0687c4b26887977e0c3'] = 'Alle deaktivieren';


return $_MODULE;
