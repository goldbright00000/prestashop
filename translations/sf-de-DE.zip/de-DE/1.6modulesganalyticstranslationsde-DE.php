<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{ganalytics}prestashop>ganalytics_d86cf69a8b82547a94ca3f6a307cf9a6'] = 'Google Analytics';
$_MODULE['<{ganalytics}prestashop>ganalytics_135d2522825fa02688ab25a2e1c88c73'] = 'Mit Google Analytics erhalten Sie Einsicht in wichtige Kennziffern zu Ihren Kunden.';
$_MODULE['<{ganalytics}prestashop>ganalytics_7ed5c154078e30b30b2f214299c5e9f5'] = 'Möchten Sie Google Analytics wirklich löschen? Sie verlieren so alle Daten, die mit diesem Modul verknüpft sind.';
$_MODULE['<{ganalytics}prestashop>ganalytics_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';
$_MODULE['<{ganalytics}prestashop>ganalytics_630f6dc397fe74e52d5189e2c80f282b'] = 'Zurück zur Übersicht';
$_MODULE['<{ganalytics}prestashop>ganalytics_f4f70727dc34561dfde1a3c529b6205c'] = 'Einstellungen';
$_MODULE['<{ganalytics}prestashop>ganalytics_851bd83a102d143ee17d97f9e15e15af'] = 'Google Analytics (Tracking-ID)';
$_MODULE['<{ganalytics}prestashop>ganalytics_ad8e83a47926dcb12e8a8fccd7fcf604'] = 'Diese Information finden Sie in Ihrem Google Analytics Account';
$_MODULE['<{ganalytics}prestashop>ganalytics_bcd08e73ca9d8bfed2cccd50dd6d8328'] = 'User-ID-Tracking aktivieren';
$_MODULE['<{ganalytics}prestashop>ganalytics_9bda6a2c3edca377eb901d7ea57c8b06'] = 'Die User-ID wird in den Property-Einstellungen generiert. Wählen Sie im Menü Verwalten ein Konto und klicken Sie dann in der Spalte Property auf Tracking-Informationen, hier auf User-ID.';
$_MODULE['<{ganalytics}prestashop>ganalytics_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Aktiviert';
$_MODULE['<{ganalytics}prestashop>ganalytics_b9f5c797ebbf55adccdd8539a65a0241'] = 'Deaktiviert';
$_MODULE['<{ganalytics}prestashop>ganalytics_612e1a524ec979815b12182c34e2daa0'] = 'User-ID erfasst!';
$_MODULE['<{ganalytics}prestashop>ganalytics_8e7b67b44506b7ac6685da041a603044'] = 'Einstellungen der User-ID wurden aktualisiert';
$_MODULE['<{ganalytics}prestashop>configuration_1f13d86a35be758509f9bdfcce5ec55d'] = 'Ihre Kunden gehen überall hin; Ihre "Analytics" sollten das auch tun!';
$_MODULE['<{ganalytics}prestashop>configuration_7063e771c3bb338ba74ac4e4716dbae1'] = 'Google Analytics zeigt Ihnen das Gesamtverhalten des Kunden in Werbung, Videos, Webseiten und Analyse sozialer Netzwerke. Das erleichtert Ihnen, die aktuellen Kunden zufriedenzustellen und neue hinzu zu gewinnen.';
$_MODULE['<{ganalytics}prestashop>configuration_df15c5cf264eb769b087f9d81aff029f'] = 'Die E-Commerce-Funktionen von Google Analytics verschaffen Ihnen den Durchblick bei wichtigen Kennziffern von Kaufverhalten und Konversion, einschließlich:';
$_MODULE['<{ganalytics}prestashop>configuration_613c191b4a1f82a454b72a840d96eefd'] = 'Aufrufe Artikelinformation';
$_MODULE['<{ganalytics}prestashop>configuration_d88b192dfe623e2a628a919b99fc1a4b'] = 'Eigener Handelserfolg';
$_MODULE['<{ganalytics}prestashop>configuration_ade6a18bb6c147db87bc9463240e455a'] = 'Artikel in Warenkorb gelegt';
$_MODULE['<{ganalytics}prestashop>configuration_c975b6b93d71b19da73114c4adcedbda'] = 'Bestellvorgang';
$_MODULE['<{ganalytics}prestashop>configuration_33f50b54625790316b86485ff3e794c4'] = 'Aktionen angeklickt';
$_MODULE['<{ganalytics}prestashop>configuration_89c48ff165eedcc3cd1bd0007115669d'] = 'und Kauf';
$_MODULE['<{ganalytics}prestashop>configuration_4632d86a96205013262bcfdd0279b39f'] = 'So lässt sich für Händler nachvollziehen, wie weit potentielle Kunden im Bestellvorgang gelangen und an welcher Stelle sie ihn abbrechen.';
$_MODULE['<{ganalytics}prestashop>configuration_16fafb5cce24f766bf2c8fcebecf76fc'] = 'Melden Sie sich an und legen Sie los!';
$_MODULE['<{ganalytics}prestashop>form-ps14_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';


return $_MODULE;
