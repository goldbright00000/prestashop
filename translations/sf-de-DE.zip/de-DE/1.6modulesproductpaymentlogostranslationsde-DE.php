<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{productpaymentlogos}prestashop>productpaymentlogos_1056d03db619b016d8fc6b60d08ef488'] = 'Block Zahlungslogos';
$_MODULE['<{productpaymentlogos}prestashop>productpaymentlogos_88fd6d994459806f2dcb8999ac03c76e'] = 'Zeigt die Logos der verfügbaren Zahlungsarten auf der Artikelseite an';
$_MODULE['<{productpaymentlogos}prestashop>productpaymentlogos_126b21ce46c39d12c24058791a236777'] = 'Bild ungültig';
$_MODULE['<{productpaymentlogos}prestashop>productpaymentlogos_df7859ac16e724c9b1fba0a364503d72'] = 'Fehler beim Hochladen der Datei';
$_MODULE['<{productpaymentlogos}prestashop>productpaymentlogos_f4f70727dc34561dfde1a3c529b6205c'] = 'Einstellungen';
$_MODULE['<{productpaymentlogos}prestashop>productpaymentlogos_223795d3a336ef80c5b6a070ae4e0d2a'] = 'Block-Header';
$_MODULE['<{productpaymentlogos}prestashop>productpaymentlogos_c7dd01cfb61ff8c984c0aff44f6540e3'] = 'Wählen Sie eine Überschrift über dem Logo-Block.';
$_MODULE['<{productpaymentlogos}prestashop>productpaymentlogos_89ca5c48bbc6b7a648a5c1996767484c'] = 'Bild';
$_MODULE['<{productpaymentlogos}prestashop>productpaymentlogos_9ce38727cff004a058021a6c7351a74a'] = 'Bild-Link';
$_MODULE['<{productpaymentlogos}prestashop>productpaymentlogos_826eeee52fe142372c3a2bc195eff911'] = 'Selbst erstellte Bilder können entweder durch Eingabe des Dateinamens oder per Link über die "Bild-Link"-Option zum Upload bereitgestellt werden.';
$_MODULE['<{productpaymentlogos}prestashop>productpaymentlogos_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';


return $_MODULE;
