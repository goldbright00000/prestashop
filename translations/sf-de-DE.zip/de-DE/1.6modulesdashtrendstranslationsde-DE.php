<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{dashtrends}prestashop>dashtrends_ee653ade5f520037ef95e9dc2a42364c'] = 'Dashboard Trends';
$_MODULE['<{dashtrends}prestashop>dashtrends_f2d0efa68eb71bfd5209abeb9f4b0943'] = 'Fügt einen Block mit einer grafischen Darstellung zur Entwicklung Ihres/r Shops basierend auf ausgewählten Kenndaten hinzu.';
$_MODULE['<{dashtrends}prestashop>dashtrends_2d125dc25b158f28a1960bd96a9fa8d1'] = '%s Punkte';
$_MODULE['<{dashtrends}prestashop>dashtrends_887ee91702c962a70b87cbef07bbcaec'] = 'zzgl. MwSt.';
$_MODULE['<{dashtrends}prestashop>dashtrends_11ff9f68afb6b8b5b8eda218d7c83a65'] = 'Umsatz';
$_MODULE['<{dashtrends}prestashop>dashtrends_7442e29d7d53e549b78d93c46b8cdcfc'] = 'Bestellungen';
$_MODULE['<{dashtrends}prestashop>dashtrends_8c804960da61b637c548c951652b0cac'] = 'Durchschnittlicher Warenkorb';
$_MODULE['<{dashtrends}prestashop>dashtrends_d7e637a6e9ff116de2fa89551240a94d'] = 'Besuche';
$_MODULE['<{dashtrends}prestashop>dashtrends_e4c3da18c66c0147144767efeb59198f'] = 'Konversionsrate';
$_MODULE['<{dashtrends}prestashop>dashtrends_43d729c7b81bfa5fc10e756660d877d1'] = 'Nettogewinn';
$_MODULE['<{dashtrends}prestashop>dashtrends_46418a037045b91e6715c4da91a2a269'] = '%s (letzte Periode)';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_2938c7f7e560ed972f8a4f68e80ff834'] = 'Übersicht';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_f1206f9fadc5ce41694f69129aecac26'] = 'Einstellungen';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_63a6a88c066880c5ac42394a22803ca6'] = 'Aktualisieren';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_e537825dd409a90ef70d8c2eb56122a1'] = 'Erlössumme (ohne MwSt.) gültiger Bestellungen im gewählten Zeitraum.';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_11ff9f68afb6b8b5b8eda218d7c83a65'] = 'Umsatz';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_8bc1c5ca521b99b87908db0bcd33ec76'] = 'Gesamtzahl gültiger Bestellungen im gewählten Zeitraum.';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_7442e29d7d53e549b78d93c46b8cdcfc'] = 'Bestellungen';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_f15f2a2bf99d3dcad2cba1a2c615b9dc'] = 'Der durchschnittliche Warenkorbwert ist eine Kennziffer für den Durchschnittswert einer Bestellung im gewählten Zeitraum. Dazu wird der Erlös durch die Anzahl der Bestellungen geteilt.';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_791d6355d34dfaf60d68ef04d1ee5767'] = 'Warenkorbwert';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_4f631447981c5fa240006a5ae2c4b267'] = 'Gesamtzahl der Besuche im gewählten Zeitraum (Als Besuch bezeichnet man den Zeitraum, währenddessen ein Besucher auf Ihrer Website aktiv ist.).';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_d7e637a6e9ff116de2fa89551240a94d'] = 'Besuche';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_7a6e858f8c7c0b78fb4d43cefcb8c017'] = 'Die E-Commerce-Konversionsrate ist der Prozentsatz von Besuchen, der auf eine gültige Bestellung entfällt.';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_e4c3da18c66c0147144767efeb59198f'] = 'Konversionsrate';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_8dedc1b3ee3a92212fb5b5acad7f207f'] = 'Der Nettogewinn ist ein Maß für die Rentabilität eines Unternehmens nach Abzug aller Kosten des E-Commerce. Sie können die Kosten erfassen, indem Sie auf das Einstellungs-Icon rechts oben klicken.';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_43d729c7b81bfa5fc10e756660d877d1'] = 'Nettogewinn';


return $_MODULE;
