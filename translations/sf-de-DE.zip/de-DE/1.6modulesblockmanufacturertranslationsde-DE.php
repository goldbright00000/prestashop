<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_bc3e73cfa718a3237fb1d7e1da491395'] = 'Block Hersteller';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_71087c7035e626bd33c72ae9a7f042af'] = 'Zeigt einen Hersteller-/Markenblock an';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_f8c922e47935b3b76a749334045d61cf'] = 'Ungültige Anzahl von Elementen';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_5b2e13ff6fa0da895d14bd56f2cb2d2d'] = 'Bitte aktivieren Sie mindestens eine Systemliste';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_f38f5974cdc23279ffe6d203641a8bdf'] = 'Einstellungen aktualisiert.';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_f4f70727dc34561dfde1a3c529b6205c'] = 'Einstellungen';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_bfdff752293014f11f17122c92909ad5'] = 'Anzeige als einfache Textliste';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_a7c6946ecc7f4ed19c2691a1e7a28f97'] = 'Hersteller als einfache Liste anzeigen';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Aktiviert';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_b9f5c797ebbf55adccdd8539a65a0241'] = 'Deaktiviert';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_2eef734f174a02ae3d7aaafefeeedb42'] = 'Anzahl anzuzeigender Elemente';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_b0fa976774d2acf72f9c62e9ab73de38'] = 'Verwenden Sie eine Dropdown-Liste';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_56353167778d1520bfecc70c470e6d8a'] = 'Hersteller als Dropdown-Liste anzeigen';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_2377be3c2ad9b435ba277a73f0f1ca76'] = 'Hersteller';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_c70ad5f80e4c6f299013e08cabc980df'] = 'Mehr über %s';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_bf24faeb13210b5a703f3ccef792b000'] = 'Alle Hersteller';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_1c407c118b89fa6feaae6b0af5fc0970'] = 'Kein Hersteller';


return $_MODULE;
