<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{eurovatgenerator}prestashop>eurovatgenerator_267e605d64e4f9568839936222896911'] = 'Europa Steuer-Generator';
$_MODULE['<{eurovatgenerator}prestashop>eurovatgenerator_d30c038f173012c8bdbed1be880e05a0'] = 'Ganz einfach Steuerregeln für virtuelle Artikel an europäisches Recht anpassen ';
$_MODULE['<{eurovatgenerator}prestashop>configure_bt_a73ab413109c43dd31f191a7d310e1ef'] = 'Europäische MwSt für virtuelle Artikel ';
$_MODULE['<{eurovatgenerator}prestashop>configure_bt_c2ef886abacc6606f222e8a12eeac91c'] = 'Das Modul generiert für Sie die Steuersätze für virtuelle Artikel in den europäischen Ländern, so dass Sie die europäischen Rechtsvorgaben für den Verkauf virtueller Artikel erfüllen können.';
$_MODULE['<{eurovatgenerator}prestashop>configure_bt_47178f09d58b5d5c42576914ede0a423'] = 'Nach Installation bitte die europäische Steuerregel den betreffenden virtuellen Artikeln Ihrer Produktpalette zuordnen.';
$_MODULE['<{eurovatgenerator}prestashop>configure_bt_d234cb6833556b58cf492990ae9d704a'] = 'Land MwSt';
$_MODULE['<{eurovatgenerator}prestashop>configure_bt_0f9f2ade08049f7b9300a6ef34949ed4'] = 'Wählen Sie für jedes Land, ob der Standard-Steuersatz bereits erfasst ist. Falls nicht, wird er automatisch angelegt.';
$_MODULE['<{eurovatgenerator}prestashop>configure_bt_29ed28e68b5c3365164aa2e0ccbe57bf'] = 'Steuersatz vorhanden ';
$_MODULE['<{eurovatgenerator}prestashop>configure_bt_b0fa79d5e3f6e671af3a8150f86ef60c'] = 'Steuersatz nicht vorhanden - wird angelegt';
$_MODULE['<{eurovatgenerator}prestashop>configure_bt_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';
$_MODULE['<{eurovatgenerator}prestashop>configure_a73ab413109c43dd31f191a7d310e1ef'] = 'Europäische MwSt für virtuelle Artikel ';
$_MODULE['<{eurovatgenerator}prestashop>configure_c2ef886abacc6606f222e8a12eeac91c'] = 'Das Modul generiert für Sie die Steuersätze für virtuelle Artikel in den europäischen Ländern, so dass Sie die europäischen Rechtsvorgaben für den Verkauf virtueller Artikel erfüllen können.';
$_MODULE['<{eurovatgenerator}prestashop>configure_47178f09d58b5d5c42576914ede0a423'] = 'Nach Installation bitte die europäische Steuerregel den betreffenden virtuellen Artikeln Ihrer Produktpalette zuordnen.';
$_MODULE['<{eurovatgenerator}prestashop>configure_d234cb6833556b58cf492990ae9d704a'] = 'Land MwSt';
$_MODULE['<{eurovatgenerator}prestashop>configure_0f9f2ade08049f7b9300a6ef34949ed4'] = 'Wählen Sie für jedes Land, ob der Standard-Steuersatz bereits erfasst ist. Falls nicht, wird er automatisch angelegt.';
$_MODULE['<{eurovatgenerator}prestashop>configure_29ed28e68b5c3365164aa2e0ccbe57bf'] = 'Steuersatz vorhanden ';
$_MODULE['<{eurovatgenerator}prestashop>configure_b0fa79d5e3f6e671af3a8150f86ef60c'] = 'Steuersatz nicht vorhanden - wird angelegt';
$_MODULE['<{eurovatgenerator}prestashop>configure_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';
$_MODULE['<{eurovatgenerator}prestashop>done_bt_7915b6921acab12d7737ea1810379b67'] = 'Alle Steuersätze erzeugt! Die neue Steuerregel "Europäische MwSt für virtuelle Artikel" ist jetzt verfügbar.';
$_MODULE['<{eurovatgenerator}prestashop>done_bt_540fca2a5a01d285cd7509b98646cb14'] = 'Was ist jetzt zu tun?';
$_MODULE['<{eurovatgenerator}prestashop>done_bt_892faeb6b5c1a83d8a8fa51562129449'] = 'Alle Steuersätze erzeugt und gesammelt in neuer Steuerregel "Europäische MwSt für virtuelle Artikel".';
$_MODULE['<{eurovatgenerator}prestashop>done_bt_e745e205828c0cddc2616ac37d06f35c'] = 'Nun bitte die neue Steuerregel den betreffenden virtuellen Artikeln Ihrer Produktpalette zuordnen.';
$_MODULE['<{eurovatgenerator}prestashop>done_bt_2ef23860578d16db7a13ba8131362bba'] = 'Das Modul lässt sicher entfernen.';
$_MODULE['<{eurovatgenerator}prestashop>done_bt_05da7f6548358c48a37680f8c8845811'] = 'Zum Katalog wechseln';
$_MODULE['<{eurovatgenerator}prestashop>done_7915b6921acab12d7737ea1810379b67'] = 'Alle Steuersätze erzeugt! Die neue Steuerregel "Europäische MwSt für virtuelle Artikel" ist jetzt verfügbar.';
$_MODULE['<{eurovatgenerator}prestashop>done_540fca2a5a01d285cd7509b98646cb14'] = 'Was ist jetzt zu tun?';
$_MODULE['<{eurovatgenerator}prestashop>done_892faeb6b5c1a83d8a8fa51562129449'] = 'Alle Steuersätze erzeugt und gesammelt in neuer Steuerregel "Europäische MwSt für virtuelle Artikel".';
$_MODULE['<{eurovatgenerator}prestashop>done_e745e205828c0cddc2616ac37d06f35c'] = 'Nun bitte die neue Steuerregel den betreffenden virtuellen Artikeln Ihrer Produktpalette zuordnen.';
$_MODULE['<{eurovatgenerator}prestashop>done_2ef23860578d16db7a13ba8131362bba'] = 'Das Modul lässt sicher entfernen.';
$_MODULE['<{eurovatgenerator}prestashop>done_05da7f6548358c48a37680f8c8845811'] = 'Zum Katalog wechseln';


return $_MODULE;
