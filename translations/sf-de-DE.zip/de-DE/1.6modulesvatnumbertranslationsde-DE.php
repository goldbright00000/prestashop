<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{vatnumber}prestashop>vatnumber_b0b9a606a1c251323825ca45d40964dc'] = 'Kein Land als Standard gesetzt.';
$_MODULE['<{vatnumber}prestashop>vatnumber_cee549912e318726d2c4989bb507665f'] = 'Europäische USt-Identifikationsnummer';
$_MODULE['<{vatnumber}prestashop>vatnumber_9fa70ad6139f2a83269df74eb6747816'] = 'Erlaubt Ihren Kunden, bei Anlage der Adresse die USt-IdNr. einzugeben. Voraussetzung dafür ist die Eingabe eines Firmennamens.';
$_MODULE['<{vatnumber}prestashop>vatnumber_162b29cf61678af2aaac37f440265c28'] = 'Ihr Land wurde aktualisiert.';
$_MODULE['<{vatnumber}prestashop>vatnumber_0ca51bcd22e4d7b56b6f1d8a01cefc1f'] = 'Die Überprüfung der USt-IdNr. mit dem WebService ist nun aktiviert.';
$_MODULE['<{vatnumber}prestashop>vatnumber_467c214bb76759108ece49873eda44e4'] = 'Die Überprüfung der USt-IdNr. mit dem WebService ist nun deaktiviert.';
$_MODULE['<{vatnumber}prestashop>vatnumber_038b34b36ec9eaf5f96d11e17f208f1b'] = '- Wählen Sie ein Land -';
$_MODULE['<{vatnumber}prestashop>vatnumber_f4f70727dc34561dfde1a3c529b6205c'] = 'Einstellungen';
$_MODULE['<{vatnumber}prestashop>vatnumber_fa01fd956e87307bce4c90a0de9b0437'] = 'Herkunftsland des Kunden';
$_MODULE['<{vatnumber}prestashop>vatnumber_7599b57d77ef1608b2f6da579794cc5b'] = 'Filter für Herkunftsland setzen';
$_MODULE['<{vatnumber}prestashop>vatnumber_da0e4b4c2ffe78456b5a1d67fd854389'] = 'Aktivieren Sie die Überprüfung der USt-IdNr. via WebService';
$_MODULE['<{vatnumber}prestashop>vatnumber_59e1a8522a3bfca342cd7110b1d67b24'] = 'Die Überprüfung durch den Webservice ist langsam. Das Aktivieren dieser Option kann Ihren Shop verlangsamen.';
$_MODULE['<{vatnumber}prestashop>vatnumber_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Aktiviert';
$_MODULE['<{vatnumber}prestashop>vatnumber_b9f5c797ebbf55adccdd8539a65a0241'] = 'Deaktiviert';
$_MODULE['<{vatnumber}prestashop>vatnumber_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';


return $_MODULE;
