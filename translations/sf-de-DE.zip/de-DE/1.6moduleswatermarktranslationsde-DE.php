<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{watermark}prestashop>watermark_ee20bb60493f049175fc10c35acd2272'] = 'Wasserzeichen';
$_MODULE['<{watermark}prestashop>watermark_8d7c07bcea7e80d072308e4bd4cc37b0'] = 'Bild schützen durch ein Wasserzeichen.';
$_MODULE['<{watermark}prestashop>watermark_69a1a3ad8dd5da6db3c4da838a0cf9c7'] = 'Möchten Sie Ihre Einstellungen wirklich löschen?';
$_MODULE['<{watermark}prestashop>watermark_2d38fba67823b23e2d5c93b5b8a5d707'] = 'Damit dieses Modul funktioniert, muss ein Wasserzeichen-Bild hochgeladen werden.';
$_MODULE['<{watermark}prestashop>watermark_842262778d363362c95aa210c9752c25'] = 'Transparenz muss angegeben sein.';
$_MODULE['<{watermark}prestashop>watermark_9d1e7d4f41c6bcac92fa25f7f615c43e'] = 'Tranzparenz ist nicht im erlaubten Bereich.';
$_MODULE['<{watermark}prestashop>watermark_d31c2d99614d8e16430d2d8c99c1f2b0'] = 'Breitenangabe erforderlich.';
$_MODULE['<{watermark}prestashop>watermark_8fe9c39f4bf87082caabcf3650970c71'] = 'Breitenangabe nicht im zulässigen Bereich.';
$_MODULE['<{watermark}prestashop>watermark_c2cf8e33c907a4cc689881dc8fa571c2'] = 'Höhenangabe erforderlich.';
$_MODULE['<{watermark}prestashop>watermark_3a1f788dbe8957be92048606cf0d3fcb'] = 'Höhenangabe nicht im zulässigen Bereich.';
$_MODULE['<{watermark}prestashop>watermark_a9cac4be0fa0b815376b96f49e1435d7'] = 'Es ist mindestens ein Bildtyp erforderlich.';
$_MODULE['<{watermark}prestashop>watermark_b670770ad59c1f8e7fb65f276074172b'] = 'Bild muss im GIF-Format sein.';
$_MODULE['<{watermark}prestashop>watermark_130aab6764f25267c79cef371270eb2a'] = 'Beim Wasserzeichen-Upload ist ein Fehler aufgetreten : %1$s nach %2$s';
$_MODULE['<{watermark}prestashop>watermark_281bec6c0d3fed2b0f5839d1ee197a6e'] = 'Das Wasserzeichen-Bild ist keine GIF-Datei. Bitte konvertieren Sie das Bild.';
$_MODULE['<{watermark}prestashop>watermark_f4f70727dc34561dfde1a3c529b6205c'] = 'Einstellungen';
$_MODULE['<{watermark}prestashop>watermark_cc99ba657a4a5ecf9d2d7cb974d25596'] = 'Sobald Sie das Modul eingestellt haben, müssen Sie die Bilder unter Voreinstellungen -> Bilder wieder herstellen. Das Wasserzeichen wird in jedem Fall automatisch zu den neuen Bildern hinzugefügt.';
$_MODULE['<{watermark}prestashop>watermark_3dad9d209b698755340cd82c93fa299d'] = 'Wasserzeichen-Datei';
$_MODULE['<{watermark}prestashop>watermark_ce4ca541df51a63fd8e78e0da29e1d44'] = 'Muss im GIF-Format sein';
$_MODULE['<{watermark}prestashop>watermark_e61514a08d28de6659551c6dce37dbed'] = 'Transparenz des Wasserzeichens (1-100)';
$_MODULE['<{watermark}prestashop>watermark_e4a60affa613d035430ab5b1f2c2dc40'] = 'Höhe Wasserzeichen';
$_MODULE['<{watermark}prestashop>watermark_811882fecd5c7618d7099ebbd39ea254'] = 'Links';
$_MODULE['<{watermark}prestashop>watermark_4a548addbfb239bbd12f5afe11a4b6dc'] = 'Mitte';
$_MODULE['<{watermark}prestashop>watermark_7c4f29407893c334a6cb7a87bf045c0d'] = 'Rechts';
$_MODULE['<{watermark}prestashop>watermark_7c60ca861e403259d8a41b5e6577788c'] = 'Breite Wasserzeichen';
$_MODULE['<{watermark}prestashop>watermark_b28354b543375bfa94dabaeda722927f'] = 'oben';
$_MODULE['<{watermark}prestashop>watermark_71f262d796bed1ab30e8a2d5a8ddee6f'] = 'unten';
$_MODULE['<{watermark}prestashop>watermark_27bd5f34e4375356363346e90dbbe2ca'] = 'Dateitypen für Wasserzeichen auswählen:';
$_MODULE['<{watermark}prestashop>watermark_b48748047a9eed520aa26ae2a8b62905'] = 'Angemeldete Kunden sehen die Bilder ohne Wasserzeichen.';
$_MODULE['<{watermark}prestashop>watermark_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Aktiviert';
$_MODULE['<{watermark}prestashop>watermark_b9f5c797ebbf55adccdd8539a65a0241'] = 'Deaktiviert';
$_MODULE['<{watermark}prestashop>watermark_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';


return $_MODULE;
