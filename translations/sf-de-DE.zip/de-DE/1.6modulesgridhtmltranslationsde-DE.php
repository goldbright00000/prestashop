<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{gridhtml}prestashop>gridhtml_cf6b972204ee563b4e5691b293e931b6'] = 'Einfache HTML-Tabelle';
$_MODULE['<{gridhtml}prestashop>gridhtml_05ce5a49b49dd6245f71e384c4b43564'] = 'Statistik in tabellarischer Form darstellen';


return $_MODULE;
