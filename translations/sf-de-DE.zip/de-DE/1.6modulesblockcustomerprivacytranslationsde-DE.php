<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_e0de5a06213f21c55ca3283c009e0907'] = 'Block Kunden-Datenschutz';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_f192f208f0bc97af4c5213eee3e78793'] = 'Fügt einen Block hinzu, um Informationen zum Kunden-Datenschutz anzuzeigen.';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'Einstellungen aktualisiert';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_fb32badede7c8613fddb8502d847c18b'] = 'Bitte stimmen Sie den Datenschutzbedingungen zu, indem Sie auf das Kontrollkästchen unten klicken.';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_f4f70727dc34561dfde1a3c529b6205c'] = 'Einstellungen';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_9a730b88a32c2932d18b8b6043cc4fb7'] = 'Auf Anmeldeformular anzeigen';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Aktiviert';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_b9f5c797ebbf55adccdd8539a65a0241'] = 'Deaktiviert';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_88997f015a0ee407a5e797011ddd090d'] = 'Datenschutzhinweis für den Kundenbereich:';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_03e1a999dcdb904300ee1b1e767c83c9'] = 'Der Datenschutzhinweis wird auf dem Anmeldeformular angezeigt.';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_b51d73fb490ad1245fa9b87042bbbbb7'] = 'Tipp: Wenn der Text für das Feld zu lang geraten ist, können Sie einen Link hinzufügen, den Sie auf der "CMS"-Seite im Menü "Voreinstellungen" angelegt haben.';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_67ebed7cf9667003ad2047609440513a'] = 'Im Kundenbereich anzeigen';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_fc67768369eadd8d4fb1e7839f5eae69'] = 'Datenschutzhinweis für den Kundenbereich:';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_432d64c20d5d06378d96c247c3f358f4'] = 'Der Datenschutzhinweis wird bei den "persönlichen Daten" im Kundenbereich angezeigt.';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_de1126ae0ac67eb4fda28cfad8429c79'] = 'Tipp: Wenn der Text für das Feld zu lang geraten ist, können Sie einen Link hinzufügen, den Sie auf der "CMS"-Seite im Menü "Voreinstellungen" angelegt haben.';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_fb0440f9ca32a8b49eded51b09e70821'] = 'Kunden-Datenschutz';


return $_MODULE;
