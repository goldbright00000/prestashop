<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{statsvisits}prestashop>statsvisits_504c16c26a96283f91fb46a69b7c8153'] = 'Besuche und Besucher';
$_MODULE['<{statsvisits}prestashop>statsvisits_432c3ab90b3af30ad318201ba09aa824'] = 'Fügt der Statikstik-Übersicht eine Auswertung der Beusche und Besucher hinzu.';
$_MODULE['<{statsvisits}prestashop>statsvisits_6602bbeb2956c035fb4cb5e844a4861b'] = 'Erklärung';
$_MODULE['<{statsvisits}prestashop>statsvisits_ffbee337f031c2282b311bac40bc8bb9'] = 'Bestimmen Sie das Ziel eines Besuchs';
$_MODULE['<{statsvisits}prestashop>statsvisits_e90d50ca1e68dc66c97bd62929dcbaf1'] = 'Die Besucherentwicklungs-Grafik sieht der Besuchs-Grafik sehr ähnlich, liefert aber zusätzliche Informationen:';
$_MODULE['<{statsvisits}prestashop>statsvisits_e9849ece0b2ecf1eea74d92d492a47f2'] = 'Falls dies der Fall ist: Gratulation! Ihre Webseite ist gut durchdacht und gefällt.';
$_MODULE['<{statsvisits}prestashop>statsvisits_c745121a98cf1d5b26bc5299d9880d5c'] = 'Ansonsten ist das Fazit nicht so einfach. Es kann sich um ein ästhetisches oder ergonomisches Problem handeln, oder das Angebot ist unzureichend. Es kann auch sein, dass diese Besucher rein zufällig auf diese Webseite gekommen sind, ohne spezielles Interesse an Ihrem Shop. Das passiert bei Suchmaschinen häufig.';
$_MODULE['<{statsvisits}prestashop>statsvisits_9bf5a493522a65d550f096505874873b'] = 'Diese Information ist hauptsächlich qualitativer Art: Sie müssen die Ursache eines zufälligen Besuchs erkennen.';
$_MODULE['<{statsvisits}prestashop>statsvisits_b8901fb7bbfaf9b0c4724343c7cd1f90'] = 'Ein Besuch entspricht einem Internet-Benutzer, der Ihren Shop besucht. Bis zum Ende des Besuchs auf der Webseite wird nur ein Besuch gezählt.';
$_MODULE['<{statsvisits}prestashop>statsvisits_f43a4cf6dcc4ec617d2296d03d26c90f'] = 'Ein Besucher ist eine unbekannte Person - die nicht registriert oder angemeldet ist - und in Ihrem Shop surft. Ein Besucher kann Ihren Shop mehrmals besuchen.';
$_MODULE['<{statsvisits}prestashop>statsvisits_54067074d24489ddb5654bf46642cb85'] = 'Besuche gesamt:';
$_MODULE['<{statsvisits}prestashop>statsvisits_23e640d55e56db79971918936e95bf9d'] = 'Besucher gesamt:';
$_MODULE['<{statsvisits}prestashop>statsvisits_998e4c5c80f27dec552e99dfed34889a'] = 'CSV-Export';
$_MODULE['<{statsvisits}prestashop>statsvisits_39b960b0a5e2ebaaa638d946f1892050'] = 'Anzahl der Besuche und einmaligen Besucher';
$_MODULE['<{statsvisits}prestashop>statsvisits_d7e637a6e9ff116de2fa89551240a94d'] = 'Besuche';
$_MODULE['<{statsvisits}prestashop>statsvisits_ae5d01b6efa819cc7a7c05a8c57fcc2c'] = 'Besucher';


return $_MODULE;
