<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockstore}prestashop>blockstore_68e9ecb0ab69b1121fe06177868b8ade'] = 'Block Shop-Finder';
$_MODULE['<{blockstore}prestashop>blockstore_c1104fe0bdaceb2e1c6f77b04977b64b'] = 'Zeigt ein Block mit einem Bild-Link zum PrestaShop Filial-Finder an';
$_MODULE['<{blockstore}prestashop>blockstore_b786bfc116ecf9a6d47ce1114ca6abb7'] = 'Das Modul kann nur an eine Spalte angedockt werden. Die gibt es aber in diesem Template nicht.';
$_MODULE['<{blockstore}prestashop>blockstore_7107f6f679c8d8b21ef6fce56fef4b93'] = 'Ungültige Bild-Datei';
$_MODULE['<{blockstore}prestashop>blockstore_df7859ac16e724c9b1fba0a364503d72'] = 'Fehler beim Hochladen der Datei';
$_MODULE['<{blockstore}prestashop>blockstore_efc226b17e0532afff43be870bff0de7'] = 'Einstellungen wurden aktualisiert.';
$_MODULE['<{blockstore}prestashop>blockstore_f4f70727dc34561dfde1a3c529b6205c'] = 'Einstellungen';
$_MODULE['<{blockstore}prestashop>blockstore_4d100d8b1b9bcb5a376f78365340cdbe'] = 'Bild für Block Shop-Finder';
$_MODULE['<{blockstore}prestashop>blockstore_a34202cc413553fe0fe2d46f706db435'] = 'Beschreibung für Block Shop-Finder';
$_MODULE['<{blockstore}prestashop>blockstore_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';
$_MODULE['<{blockstore}prestashop>blockstore_8c0caec5616160618b362bcd4427d97b'] = 'Unsere Filiale(n)';
$_MODULE['<{blockstore}prestashop>blockstore_28fe12f949fd191685071517628df9b3'] = 'Entdecken Sie unsere Filiale(n)!';
$_MODULE['<{blockstore}prestashop>blockstore_34c869c542dee932ef8cd96d2f91cae6'] = 'Unsere Filialen';
$_MODULE['<{blockstore}prestashop>blockstore_61d5070a61ce6eb6ad2a212fdf967d92'] = 'Hier finden Sie uns';


return $_MODULE;
