<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{statsequipment}prestashop>statsequipment_247270d410e2b9de01814b82111becda'] = 'Browser und Betriebssysteme';
$_MODULE['<{statsequipment}prestashop>statsequipment_2876718a648dea03aaafd4b5a63b1efe'] = 'Fügt der Statistik-Übersicht eine graphische Auswertung der Browser und Betriebsysteme Ihrer Kunden hinzu';
$_MODULE['<{statsequipment}prestashop>statsequipment_6602bbeb2956c035fb4cb5e844a4861b'] = 'Erklärung';
$_MODULE['<{statsequipment}prestashop>statsequipment_854c8e126f839cc861cde822b641230e'] = 'Sicherstellen, dass Ihre Webseite für soviele wie möglich erreichbar ist';
$_MODULE['<{statsequipment}prestashop>statsequipment_0d5f13106dec10bb8a9301541052278c'] = 'Bei der Webseitenverwaltung ist es wichtig, die vom Kunden genutzte Software im Auge zu behalten, um sicher zu gehen, dass die Webseite bei jedem Kunden das Gleiche anzeigt. PrestaShop wurde so konzipiert, dass es mit den meisten neueren Webbrowsern und Betriebssystemen kompatibel ist. Falls Sie jedoch Ihren Shop durch fortgeschrittene Funktionen erweitern oder sogar den PrestaShop Core Code verändern, könnten diese nicht für alle Kunden richtig dargestellt werden. Sie sollten deshalb immer den Überblick darüber behalten, wie groß der Anteil Ihrer Kunden mit der jeweiligen Software ist, bevor Sie etwas ändern oder hinzufügen, auf das nur eine begrenzte Anzahl von Nutzern Zugriff hat.';
$_MODULE['<{statsequipment}prestashop>statsequipment_11db1362a88c5e3e74c8f699c14d6798'] = 'Zeigt die von Ihren Kunden benutzten Browser (in Prozent).';
$_MODULE['<{statsequipment}prestashop>statsequipment_998e4c5c80f27dec552e99dfed34889a'] = 'CSV-Export';
$_MODULE['<{statsequipment}prestashop>statsequipment_90c58bfe4872fc9ca7bf6a181c3e5edd'] = 'Zeigt die von Ihren Kunden genutzten Betriebssysteme (in Prozent).';
$_MODULE['<{statsequipment}prestashop>statsequipment_bb38096ab39160dc20d44f3ea6b44507'] = 'Plug-ins';
$_MODULE['<{statsequipment}prestashop>statsequipment_9ffafc9e090c8e1c06f928ef2817efd6'] = 'Browser';
$_MODULE['<{statsequipment}prestashop>statsequipment_0241b7aaaa5f76afd585bb6cdae314d1'] = 'Betriebssystem';


return $_MODULE;
